async function fet() {
    const data = await fetch("https://dummyapi.online/api/movies");
    const fdata = await data.json();
    console.log(fdata);

    const videoContainer = document.getElementById('video-container');
    const maxVideos = 8;

    let row = document.createElement('div');
    row.style.display = 'flex';
    row.style.flexWrap = 'wrap';
    videoContainer.appendChild(row);

    fdata.slice(0, maxVideos).forEach((element, index) => {
        const videoDiv = document.createElement('div');
        videoDiv.className = 'video-div';
        videoDiv.style.flex = '1';

        const video = document.createElement('video');
        video.src = element.videoURL || 'https://www.example.com/path/to/video.mp4';
        video.type = 'video/mp4';
        video.controls = true;
        video.style.marginLeft = '500px';

        // Event listener to open next.html with video URLs
        video.addEventListener('click', () => {
            window.location.href = `next.html?videoIndex=${index}`;
        });

        videoDiv.appendChild(video);
        row.appendChild(videoDiv);

        if ((index + 1) % 4 === 0 && index + 1 !== maxVideos) {
            row = document.createElement('div');
            row.style.display = 'flex';
            row.style.flexWrap = 'wrap';
            videoContainer.appendChild(row);
        }
    });
}

fet();
