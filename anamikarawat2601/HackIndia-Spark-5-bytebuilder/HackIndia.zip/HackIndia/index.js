const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const app = express();

app.use(bodyParser.json());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

mongoose.connect('mongodb://localhost:27017/Database', { useNewUrlParser: true, useUnifiedTopology: true });
var db = mongoose.connection;
db.on('error', () => {
    console.log("Error in connecting to database");
});
db.once('open', () => {
    console.log("Connected to database");
});

// Schema and model for email
const emailSchema = new mongoose.Schema({
    email: String
});

const Email = mongoose.model('Email', emailSchema);

app.post("/submit-email", (req, res) => {
    const email = req.body.email;

    const newEmail = new Email({ email });

    newEmail.save((err) => {
        if (err) {
            console.error("Error inserting email: ", err);
            return res.status(500).send("An error occurred while inserting the email.");
        }
        console.log("Email Inserted Successfully");
        return res.send("Email submitted successfully");
    });
});


app.get("/", (req, res) => {
    res.set({
        "Allow-access-Allow-Origin": '*'
    });
    return res.redirect('index.html');
}).listen(2200, () => {
    console.log("Listening on port 2200");
});
