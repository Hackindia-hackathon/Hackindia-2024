# pyv8-prebuilt
Prebuilt versions of pyv8

These are built from the source at [pebble/pyv8](https://github.com/pebble/pyv8.git)
and licensed under the [Apache License 2.0](http://www.apache.org/licenses/LICENSE-2.0).
