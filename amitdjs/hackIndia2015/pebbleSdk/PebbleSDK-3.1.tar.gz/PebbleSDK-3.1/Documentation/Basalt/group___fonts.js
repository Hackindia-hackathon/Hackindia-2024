var group___fonts =
[
    [ "fonts_get_system_font", "group___fonts.html#ga8d05ec62a2e79c75b2938c2e2d6ba70a", null ],
    [ "fonts_load_custom_font", "group___fonts.html#gaaf4a526b0bbe417959eb7935b89a5f56", null ],
    [ "fonts_unload_custom_font", "group___fonts.html#gae25249ea28fddf938ef900efdcf1777c", null ],
    [ "GFont", "group___fonts.html#ga49c1c67f30e577eb50ab54cd5526cb7a", null ]
];