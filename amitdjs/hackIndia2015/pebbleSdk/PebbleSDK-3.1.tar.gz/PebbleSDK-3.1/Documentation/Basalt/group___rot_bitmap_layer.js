var group___rot_bitmap_layer =
[
    [ "rot_bitmap_layer_create", "group___rot_bitmap_layer.html#ga8813c8dda16b21688de6492540b8c69e", null ],
    [ "rot_bitmap_layer_destroy", "group___rot_bitmap_layer.html#ga8b3b96d607c07aa1a64a0bf6c78f5bf5", null ],
    [ "rot_bitmap_layer_increment_angle", "group___rot_bitmap_layer.html#ga1392050689ca39d86949c8b4744ddaa2", null ],
    [ "rot_bitmap_layer_set_angle", "group___rot_bitmap_layer.html#ga0aa9e535226e88bad75410ce177c27af", null ],
    [ "rot_bitmap_layer_set_corner_clip_color", "group___rot_bitmap_layer.html#ga05bb6f3e05c774b3e20b8ff4d1068d67", null ],
    [ "rot_bitmap_set_compositing_mode", "group___rot_bitmap_layer.html#ga5ddf5cbe3499a3ee5487e82d5d5659d2", null ],
    [ "rot_bitmap_set_src_ic", "group___rot_bitmap_layer.html#ga455a2e9f47703fe44a1054ff02396162", null ]
];