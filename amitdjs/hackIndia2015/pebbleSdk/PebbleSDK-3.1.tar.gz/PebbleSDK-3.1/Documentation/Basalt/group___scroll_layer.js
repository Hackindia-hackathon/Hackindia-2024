var group___scroll_layer =
[
    [ "scroll_layer_add_child", "group___scroll_layer.html#ga318c7ebc11aa6d2ecf12c534bf1274cb", null ],
    [ "scroll_layer_create", "group___scroll_layer.html#gab88b8cf8308e3d68d5e714db11658e62", null ],
    [ "scroll_layer_destroy", "group___scroll_layer.html#ga2fa5ed30c56396db4f3b0325d3e22365", null ],
    [ "scroll_layer_get_content_offset", "group___scroll_layer.html#ga2fda3786915d157310adc5cca2db535a", null ],
    [ "scroll_layer_get_content_size", "group___scroll_layer.html#gaaf9a11857e592b96f6e98f883d3bb479", null ],
    [ "scroll_layer_get_layer", "group___scroll_layer.html#ga9cb8e737c9b713b7807121c44ad19873", null ],
    [ "scroll_layer_get_shadow_hidden", "group___scroll_layer.html#gaf77b23563424e49f40b6da8972b8c950", null ],
    [ "scroll_layer_scroll_down_click_handler", "group___scroll_layer.html#ga5e9eb81851e021f62a552e304b5eca49", null ],
    [ "scroll_layer_scroll_up_click_handler", "group___scroll_layer.html#ga54271d3c507498c6548d142b017c949a", null ],
    [ "scroll_layer_set_callbacks", "group___scroll_layer.html#ga2aaf8ab053b356ccfc61afefe2504faf", null ],
    [ "scroll_layer_set_click_config_onto_window", "group___scroll_layer.html#ga2c65fbd5bdc6af121312141368207775", null ],
    [ "scroll_layer_set_content_offset", "group___scroll_layer.html#ga09d6b9d6b9016eb438a7e3d51eb4041d", null ],
    [ "scroll_layer_set_content_size", "group___scroll_layer.html#ga95d1e0f61d1bf54eabd1c59f3e295489", null ],
    [ "scroll_layer_set_context", "group___scroll_layer.html#gaeb62332973b899f585563270fa7db637", null ],
    [ "scroll_layer_set_frame", "group___scroll_layer.html#ga9282d6e6c53061b26b2df60e8b2d9553", null ],
    [ "scroll_layer_set_shadow_hidden", "group___scroll_layer.html#gab8d87f6647984e9532e848f04f610ae6", null ],
    [ "ScrollLayerCallback", "group___scroll_layer.html#ga562d848f7db8d2c1fa10d99b256a8b3c", null ]
];