var group___path_drawing =
[
    [ "gpath_create", "group___path_drawing.html#ga61db1b8ea3038564f1393f0cab1c8ff9", null ],
    [ "gpath_destroy", "group___path_drawing.html#gafee45d9c181217758e27bdaa577d98e0", null ],
    [ "gpath_draw_filled", "group___path_drawing.html#ga4aa5b80f8f98d2cb7e6701b39bb18e32", null ],
    [ "gpath_draw_outline", "group___path_drawing.html#ga33e423daf4e125ae273111871159eead", null ],
    [ "gpath_draw_outline_open", "group___path_drawing.html#gaa09ae35d22e854a2b8408d2f1ee96e93", null ],
    [ "gpath_move_to", "group___path_drawing.html#ga1ba79344b9a34432a44af09bed8b00fd", null ],
    [ "gpath_rotate_to", "group___path_drawing.html#ga152abe6dd44cf1d69709603bc41eb0e3", null ]
];