var group___wakeup =
[
    [ "wakeup_cancel", "group___wakeup.html#gabbe54a1d30d2fc18694572961fd4e89f", null ],
    [ "wakeup_cancel_all", "group___wakeup.html#ga1e6e5dd7843ce0a1c9f88593617fcf3a", null ],
    [ "wakeup_get_launch_event", "group___wakeup.html#ga4b39e11604da247e2ee7a9249d75169b", null ],
    [ "wakeup_query", "group___wakeup.html#ga20cedaca47991ed554ec624630e529a6", null ],
    [ "wakeup_schedule", "group___wakeup.html#ga8c69fb46a7fdbc0a77fae0f6a2f9da5d", null ],
    [ "wakeup_service_subscribe", "group___wakeup.html#gaea67463087f97d88fd136525c8101f51", null ],
    [ "WakeupHandler", "group___wakeup.html#ga1d8a498ef287e56299b4e1985181d46d", null ],
    [ "WakeupId", "group___wakeup.html#ga012047a2e8fa4d77a788324144e15c8f", null ]
];