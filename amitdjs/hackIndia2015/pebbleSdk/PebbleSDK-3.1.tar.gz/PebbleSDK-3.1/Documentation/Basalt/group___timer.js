var group___timer =
[
    [ "app_timer_cancel", "group___timer.html#ga00bc7ef3a57f2321c5f88e7820724825", null ],
    [ "app_timer_register", "group___timer.html#gac6c8b77f2d03fa1dc39eb60f5e88d5e0", null ],
    [ "app_timer_reschedule", "group___timer.html#ga34584069c4304e375425549f13cad1e6", null ],
    [ "psleep", "group___timer.html#ga00f41133e14542220d184131f9dcb863", null ],
    [ "AppTimerCallback", "group___timer.html#ga8a4db73d39797eeb1d21200533532f48", null ]
];