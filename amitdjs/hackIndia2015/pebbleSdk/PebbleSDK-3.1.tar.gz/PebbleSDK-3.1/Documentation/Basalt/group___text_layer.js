var group___text_layer =
[
    [ "text_layer_create", "group___text_layer.html#gaadc296e7be9f534e4c17be4c30b2a25a", null ],
    [ "text_layer_destroy", "group___text_layer.html#ga17a045487e54ec95c989434bd7289242", null ],
    [ "text_layer_get_content_size", "group___text_layer.html#ga35fe649d979d4b002589fbaf86604f2a", null ],
    [ "text_layer_get_layer", "group___text_layer.html#gacd21169c63f3cfa4276d203c4df281f4", null ],
    [ "text_layer_get_text", "group___text_layer.html#ga525fc7f0a6ef9f7ae6fffb5d4cd7c9de", null ],
    [ "text_layer_set_background_color", "group___text_layer.html#gabfeaa5a8a8062c5ed6c31c0dc853bc28", null ],
    [ "text_layer_set_font", "group___text_layer.html#gadb8ccc8f9a14ab4a2386f6ccac8de0f1", null ],
    [ "text_layer_set_overflow_mode", "group___text_layer.html#ga654f359a8f5736aa5ca82735d8b03b16", null ],
    [ "text_layer_set_size", "group___text_layer.html#ga3548811ef658bdc7755fe53f16d6e23b", null ],
    [ "text_layer_set_text", "group___text_layer.html#ga19406f772604d595c5c1af7222992449", null ],
    [ "text_layer_set_text_alignment", "group___text_layer.html#gaf44cc52cecaa94867d927130da4d4aca", null ],
    [ "text_layer_set_text_color", "group___text_layer.html#ga4e94ca9f977475342b3cccaf7e503515", null ]
];