var searchData=
[
  ['compassstatuscalibrated',['CompassStatusCalibrated',['../group___compass_service.html#gga1fccbe1b49cd0a60381d6862ae193551ace38e71f0329bdfda367ead50e4f1a8a',1,'pebble.h']]],
  ['compassstatuscalibrating',['CompassStatusCalibrating',['../group___compass_service.html#gga1fccbe1b49cd0a60381d6862ae193551a0af51058d882231ca0a060146c9b1ab4',1,'pebble.h']]],
  ['compassstatusdatainvalid',['CompassStatusDataInvalid',['../group___compass_service.html#gga1fccbe1b49cd0a60381d6862ae193551a0d78212704530d734057bd9c414407be',1,'pebble.h']]]
];
