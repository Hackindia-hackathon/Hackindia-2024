var searchData=
[
  ['gpath',['GPath',['../group___path_drawing.html#struct_g_path',1,'']]],
  ['gpathinfo',['GPathInfo',['../group___path_drawing.html#struct_g_path_info',1,'']]],
  ['gpoint',['GPoint',['../group___graphics_types.html#struct_g_point',1,'']]],
  ['grect',['GRect',['../group___graphics_types.html#struct_g_rect',1,'']]],
  ['gsize',['GSize',['../group___graphics_types.html#struct_g_size',1,'']]]
];
