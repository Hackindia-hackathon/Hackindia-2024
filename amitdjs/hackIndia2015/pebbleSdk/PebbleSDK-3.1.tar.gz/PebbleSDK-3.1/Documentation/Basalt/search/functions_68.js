var searchData=
[
  ['heap_5fbytes_5ffree',['heap_bytes_free',['../group___memory_management.html#ga887f21116cdcf560a095bbbc786686b9',1,'pebble.h']]],
  ['heap_5fbytes_5fused',['heap_bytes_used',['../group___memory_management.html#ga9e776141c2f26b29e3b94dfca5d482a4',1,'pebble.h']]]
];
