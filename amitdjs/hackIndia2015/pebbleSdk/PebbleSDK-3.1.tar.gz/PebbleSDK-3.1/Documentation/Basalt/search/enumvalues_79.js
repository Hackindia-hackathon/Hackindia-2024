var searchData=
[
  ['year_5funit',['YEAR_UNIT',['../group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107a652f00ea2c629930a32a684f9d8c876d',1,'pebble.h']]]
];
