var searchData=
[
  ['compassstatus',['CompassStatus',['../group___compass_service.html#ga1fccbe1b49cd0a60381d6862ae193551',1,'pebble.h']]]
];
