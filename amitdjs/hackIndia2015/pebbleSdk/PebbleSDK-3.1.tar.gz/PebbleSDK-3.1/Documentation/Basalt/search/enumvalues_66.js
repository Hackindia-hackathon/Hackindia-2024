var searchData=
[
  ['friday',['FRIDAY',['../group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a8f589731fd90a9890c0df9a9c3f96131',1,'pebble.h']]]
];
