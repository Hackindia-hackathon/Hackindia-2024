var searchData=
[
  ['w',['w',['../group___graphics_types.html#ab4b00bc79cc43d5554d19fd273fe37e0',1,'GSize']]]
];
