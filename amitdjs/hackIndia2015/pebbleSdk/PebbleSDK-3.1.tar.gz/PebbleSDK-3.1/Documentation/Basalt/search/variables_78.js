var searchData=
[
  ['x',['x',['../group___accelerometer_service.html#abe5df85a74073f78086968cbbe82b32f',1,'AccelData::x()'],['../group___accelerometer_service.html#a918cd7be9f4ad84dca85d76e8e866259',1,'AccelRawData::x()'],['../group___graphics_types.html#a1f1a9ce775dde3448a265dc36b2024f4',1,'GPoint::x()']]]
];
