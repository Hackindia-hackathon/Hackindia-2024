var searchData=
[
  ['icon',['icon',['../group___simple_menu_layer.html#abdcb2509876059ad6c0f2a887927f952',1,'SimpleMenuItem']]],
  ['incremented',['incremented',['../group___number_window.html#a859555b6e90e9f30ebf83ade1843edb4',1,'NumberWindowCallbacks']]],
  ['is_5fcharging',['is_charging',['../group___battery_state_service.html#a1a2d28c28d3d230b5f8fe2fd089ff9dd',1,'BatteryChargeState']]],
  ['is_5fdeclination_5fvalid',['is_declination_valid',['../group___compass_service.html#a244791d533094a407a3879686d532afd',1,'CompassHeadingData']]],
  ['is_5fplugged',['is_plugged',['../group___battery_state_service.html#a00910c85f1f068363a7b400151b7f8e4',1,'BatteryChargeState']]],
  ['items',['items',['../group___simple_menu_layer.html#a377ff366a71e19cfe6c1dbb8f233f91b',1,'SimpleMenuSection']]]
];
