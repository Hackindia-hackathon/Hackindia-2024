var searchData=
[
  ['batterystateservice',['BatteryStateService',['../group___battery_state_service.html',1,'']]],
  ['bitmaplayer',['BitmapLayer',['../group___bitmap_layer.html',1,'']]],
  ['bluetoothconnectionservice',['BluetoothConnectionService',['../group___bluetooth_connection_service.html',1,'']]]
];
