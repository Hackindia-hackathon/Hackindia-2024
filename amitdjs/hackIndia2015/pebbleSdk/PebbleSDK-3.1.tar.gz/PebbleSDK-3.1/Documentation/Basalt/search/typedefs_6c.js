var searchData=
[
  ['layerupdateproc',['LayerUpdateProc',['../group___layer.html#ga5bf7c903e32df0edcb1ec0b23d367bf0',1,'pebble.h']]]
];
