var searchData=
[
  ['dataloggingitemtype',['DataLoggingItemType',['../group___data_logging.html#ga35a7aa37609a9aebb3ad316e77cb716d',1,'pebble.h']]],
  ['dataloggingresult',['DataLoggingResult',['../group___data_logging.html#gaddc3b8874990b538c7fe17b019ace38f',1,'pebble.h']]],
  ['dictionaryresult',['DictionaryResult',['../group___dictionary.html#gaafae887a6d07cde8d11885c755b55351',1,'pebble.h']]]
];
