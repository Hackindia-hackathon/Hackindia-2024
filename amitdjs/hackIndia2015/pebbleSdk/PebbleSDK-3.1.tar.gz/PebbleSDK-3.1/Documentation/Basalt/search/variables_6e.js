var searchData=
[
  ['num_5fitems',['num_items',['../group___simple_menu_layer.html#ac0331245bc7c1a881acf42d00c4f6789',1,'SimpleMenuSection']]],
  ['num_5fpoints',['num_points',['../group___path_drawing.html#a58f935742a1b1cfde88cfcadd172a09b',1,'GPathInfo::num_points()'],['../group___path_drawing.html#aaefbfeade709d357a25b19a88f663460',1,'GPath::num_points()']]],
  ['num_5fsegments',['num_segments',['../group___vibes.html#a0ea4a7f770c28f400daf3bd255e730e7',1,'VibePattern']]]
];
