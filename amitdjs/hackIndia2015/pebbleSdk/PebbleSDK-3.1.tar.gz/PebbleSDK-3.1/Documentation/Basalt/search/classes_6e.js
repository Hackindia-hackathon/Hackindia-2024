var searchData=
[
  ['numberwindowcallbacks',['NumberWindowCallbacks',['../group___number_window.html#struct_number_window_callbacks',1,'']]]
];
