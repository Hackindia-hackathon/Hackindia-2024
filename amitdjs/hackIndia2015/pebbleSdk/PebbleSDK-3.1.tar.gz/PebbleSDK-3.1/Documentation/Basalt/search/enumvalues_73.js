var searchData=
[
  ['s_5ffalse',['S_FALSE',['../group___storage.html#ggae98a46f4ea1a43ca48acaf15d2eb7113a68f36740ce22fa7b0a5500578751c4df',1,'pebble.h']]],
  ['s_5fno_5faction_5frequired',['S_NO_ACTION_REQUIRED',['../group___storage.html#ggae98a46f4ea1a43ca48acaf15d2eb7113a84443a6682392b6f7afa83fd096325cb',1,'pebble.h']]],
  ['s_5fno_5fmore_5fitems',['S_NO_MORE_ITEMS',['../group___storage.html#ggae98a46f4ea1a43ca48acaf15d2eb7113ae1acf82ac9fe0261196ad98e1aa66008',1,'pebble.h']]],
  ['s_5fsuccess',['S_SUCCESS',['../group___storage.html#ggae98a46f4ea1a43ca48acaf15d2eb7113a29c0c697bde0c7eb16b7f17bea656fb9',1,'pebble.h']]],
  ['s_5ftrue',['S_TRUE',['../group___storage.html#ggae98a46f4ea1a43ca48acaf15d2eb7113a634340f260a88ae2889c4cf0502cc08b',1,'pebble.h']]],
  ['saturday',['SATURDAY',['../group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a31bbcd6fa6a28095ef8de658126aa5ec',1,'pebble.h']]],
  ['second_5funit',['SECOND_UNIT',['../group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107afd448b8fbcd39321d18aa41b62b308b9',1,'pebble.h']]],
  ['sniff_5finterval_5fnormal',['SNIFF_INTERVAL_NORMAL',['../group___app_comm.html#ggad85d78fd5b9d36fb69242afa57e79f48a3b964e796c51c86c94eadf17b8dbcf17',1,'pebble.h']]],
  ['sniff_5finterval_5freduced',['SNIFF_INTERVAL_REDUCED',['../group___app_comm.html#ggad85d78fd5b9d36fb69242afa57e79f48a8de75571a0bcf3ac565ced0628577382',1,'pebble.h']]],
  ['statusbarlayerseparatormodedotted',['StatusBarLayerSeparatorModeDotted',['../group___status_bar_layer.html#ggaf7316a23f8fa3b482551ea4cbbb414faa15cfb9da70e7753b3e8efeaedaa1b318',1,'pebble.h']]],
  ['statusbarlayerseparatormodenone',['StatusBarLayerSeparatorModeNone',['../group___status_bar_layer.html#ggaf7316a23f8fa3b482551ea4cbbb414faa5fd87a47081ee5add2afa2d67d3ab9c6',1,'pebble.h']]],
  ['sunday',['SUNDAY',['../group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5ad86a75e0b97510de54435996ae45b8d2',1,'pebble.h']]]
];
