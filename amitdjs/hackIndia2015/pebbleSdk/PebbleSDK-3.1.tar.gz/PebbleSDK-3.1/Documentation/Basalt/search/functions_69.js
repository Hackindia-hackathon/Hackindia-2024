var searchData=
[
  ['i18n_5fget_5fsystem_5flocale',['i18n_get_system_locale',['../group___internationalization.html#gaab8c203d34253c4cedf7dd2debb02bfb',1,'pebble.h']]]
];
