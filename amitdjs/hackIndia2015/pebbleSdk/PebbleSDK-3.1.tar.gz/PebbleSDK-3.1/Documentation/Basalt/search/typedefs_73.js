var searchData=
[
  ['scrolllayercallback',['ScrollLayerCallback',['../group___scroll_layer.html#ga562d848f7db8d2c1fa10d99b256a8b3c',1,'pebble.h']]],
  ['simplemenulayerselectcallback',['SimpleMenuLayerSelectCallback',['../group___simple_menu_layer.html#gac877ef0d29ee59537df4da1e9e226c1a',1,'pebble.h']]],
  ['size_5ft',['size_t',['../group___standard_memory.html#ga7b60c5629e55e8ec87a4547dd4abced4',1,'common.dox']]],
  ['status_5ft',['status_t',['../group___storage.html#gaaabdaf7ee58ca7269bd4bf24efcde092',1,'pebble.h']]]
];
