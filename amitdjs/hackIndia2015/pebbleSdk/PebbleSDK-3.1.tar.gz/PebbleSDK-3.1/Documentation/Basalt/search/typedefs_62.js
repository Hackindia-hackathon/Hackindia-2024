var searchData=
[
  ['batterystatehandler',['BatteryStateHandler',['../group___battery_state_service.html#ga06471c5ea82209d1d80e0671bae09325',1,'pebble.h']]],
  ['bluetoothconnectionhandler',['BluetoothConnectionHandler',['../group___bluetooth_connection_service.html#gac6034eb9fbf5eb0827ff53a7bbac5aeb',1,'pebble.h']]]
];
