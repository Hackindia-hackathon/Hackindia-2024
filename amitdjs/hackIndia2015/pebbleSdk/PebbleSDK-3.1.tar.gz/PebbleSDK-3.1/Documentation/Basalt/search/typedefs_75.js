var searchData=
[
  ['uint16_5ft',['uint16_t',['../group___standard_c.html#gabf6633e0fef9023e8a1e8d727f4023e1',1,'common.dox']]],
  ['uint32_5ft',['uint32_t',['../group___standard_c.html#gad53b3f685c3f3153f35ec87ea6f349d1',1,'common.dox']]],
  ['uint32getter',['UInt32Getter',['../group___property_animation.html#ga0320e0ff69acf9aad6259a9d7227bf7f',1,'pebble.h']]],
  ['uint32setter',['UInt32Setter',['../group___property_animation.html#gae3ee0aa676995be46fa8c73a1802477b',1,'pebble.h']]]
];
