var searchData=
[
  ['num_5fbuttons',['NUM_BUTTONS',['../group___clicks.html#ggaa60e15d86cfe7033f28c7d066c85266eac81067fe4db9cdff7042b4d9efb5f4cb',1,'pebble.h']]]
];
