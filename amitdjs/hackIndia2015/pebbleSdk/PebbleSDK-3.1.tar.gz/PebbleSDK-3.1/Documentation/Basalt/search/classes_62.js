var searchData=
[
  ['batterychargestate',['BatteryChargeState',['../group___battery_state_service.html#struct_battery_charge_state',1,'']]]
];
