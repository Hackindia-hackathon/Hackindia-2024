var group___memory_management =
[
    [ "heap_bytes_free", "group___memory_management.html#ga887f21116cdcf560a095bbbc786686b9", null ],
    [ "heap_bytes_used", "group___memory_management.html#ga9e776141c2f26b29e3b94dfca5d482a4", null ]
];