var group___bluetooth_connection_service =
[
    [ "bluetooth_connection_service_peek", "group___bluetooth_connection_service.html#ga31ae0c22e1cbf2af34b39b49e98c777a", null ],
    [ "bluetooth_connection_service_subscribe", "group___bluetooth_connection_service.html#ga6661ab4bdb986715602183b7849ffe84", null ],
    [ "bluetooth_connection_service_unsubscribe", "group___bluetooth_connection_service.html#gae3a446e0d93d0d71f4265d5ff9352c0a", null ],
    [ "BluetoothConnectionHandler", "group___bluetooth_connection_service.html#gac6034eb9fbf5eb0827ff53a7bbac5aeb", null ]
];