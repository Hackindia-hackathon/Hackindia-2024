var group___standard_c =
[
    [ "Format", "group___standard_i_o.html", "group___standard_i_o" ],
    [ "Locale", "group___standard_locale.html", "group___standard_locale" ],
    [ "Math", "group___standard_math.html", "group___standard_math" ],
    [ "Memory", "group___standard_memory.html", "group___standard_memory" ],
    [ "String", "group___standard_string.html", "group___standard_string" ],
    [ "Time", "group___standard_time.html", "group___standard_time" ],
    [ "uint16_t", "group___standard_c.html#gabf6633e0fef9023e8a1e8d727f4023e1", null ],
    [ "uint32_t", "group___standard_c.html#gad53b3f685c3f3153f35ec87ea6f349d1", null ]
];