var group___foundation =
[
    [ "App", "group___app.html", "group___app" ],
    [ "App Communication", "group___app_comm.html", "group___app_comm" ],
    [ "AppMessage", "group___app_message.html", "group___app_message" ],
    [ "AppSync", "group___app_sync.html", "group___app_sync" ],
    [ "AppWorker", "group___app_worker.html", "group___app_worker" ],
    [ "DataLogging", "group___data_logging.html", "group___data_logging" ],
    [ "DataStructures", "group___data_structures.html", "group___data_structures" ],
    [ "Dictionary", "group___dictionary.html", "group___dictionary" ],
    [ "Event Service", "group___event_service.html", "group___event_service" ],
    [ "Internationalization", "group___internationalization.html", "group___internationalization" ],
    [ "Launch Reason", "group___launch_reason.html", "group___launch_reason" ],
    [ "Logging", "group___logging.html", "group___logging" ],
    [ "Math", "group___math.html", "group___math" ],
    [ "Memory Management", "group___memory_management.html", "group___memory_management" ],
    [ "Resources", "group___resources.html", "group___resources" ],
    [ "Storage", "group___storage.html", "group___storage" ],
    [ "Timer", "group___timer.html", "group___timer" ],
    [ "Wakeup", "group___wakeup.html", "group___wakeup" ],
    [ "Wall Time", "group___wall_time.html", "group___wall_time" ],
    [ "WatchInfo", "group___watch_info.html", "group___watch_info" ]
];