var group___window_stack =
[
    [ "window_stack_contains_window", "group___window_stack.html#ga9be3883d911fd1ea49c9207c219bc4bd", null ],
    [ "window_stack_get_top_window", "group___window_stack.html#gaada26c4ca80062472cedc1e86ef29a11", null ],
    [ "window_stack_pop", "group___window_stack.html#gaedab08317d26dca178a994563db77862", null ],
    [ "window_stack_pop_all", "group___window_stack.html#gacfbb60a6addd140d2b94f659b8630306", null ],
    [ "window_stack_push", "group___window_stack.html#gabc91655655af8fd71ac7c081f40d69b2", null ],
    [ "window_stack_remove", "group___window_stack.html#ga44a239d564b96ca93a149a29d89707d1", null ]
];