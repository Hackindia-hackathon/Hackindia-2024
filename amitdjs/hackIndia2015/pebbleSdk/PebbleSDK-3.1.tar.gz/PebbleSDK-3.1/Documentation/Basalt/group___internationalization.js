var group___internationalization =
[
    [ "i18n_get_system_locale", "group___internationalization.html#gaab8c203d34253c4cedf7dd2debb02bfb", null ]
];