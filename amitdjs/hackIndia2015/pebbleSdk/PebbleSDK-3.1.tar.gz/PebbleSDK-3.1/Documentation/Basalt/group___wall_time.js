var group___wall_time =
[
    [ "clock_copy_time_string", "group___wall_time.html#ga5ddf6b7454fd49c0eb63d2e50d75fad7", null ],
    [ "clock_get_timezone", "group___wall_time.html#gae34db14b2f1e369c23894bffb6663fc8", null ],
    [ "clock_is_24h_style", "group___wall_time.html#ga69393fbc51be905740fff59a150bdca9", null ],
    [ "clock_is_timezone_set", "group___wall_time.html#ga95c658aa0d511e4b4ca549724e02ce72", null ],
    [ "clock_to_timestamp", "group___wall_time.html#ga170869bfe009abc85f093b0f80224009", null ],
    [ "WeekDay", "group___wall_time.html#ga38e35eaba0dce3be153ec798fb175de5", [
      [ "TODAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5ac738929b5715d2179b64240f54a7677e", null ],
      [ "SUNDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5ad86a75e0b97510de54435996ae45b8d2", null ],
      [ "MONDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5ac82db3248a96794aaefb922ea5fb293c", null ],
      [ "TUESDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a347c4455723bb1bc2709647607a2b282", null ],
      [ "WEDNESDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a68288a23958cd9e1705fd81f0ee729c7", null ],
      [ "THURSDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5ab4bfd6f883437c6cf31486dcf03ce0ff", null ],
      [ "FRIDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a8f589731fd90a9890c0df9a9c3f96131", null ],
      [ "SATURDAY", "group___wall_time.html#gga38e35eaba0dce3be153ec798fb175de5a31bbcd6fa6a28095ef8de658126aa5ec", null ]
    ] ],
    [ "TIMEZONE_NAME_LENGTH", "group___wall_time.html#ga4bed5f27a148b3560766fb6e2e573e01", null ]
];