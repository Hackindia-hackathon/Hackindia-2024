var group___app_focus_service =
[
    [ "app_focus_service_subscribe", "group___app_focus_service.html#gad3b5ca8c13082e236e1334d60307ae9e", null ],
    [ "app_focus_service_unsubscribe", "group___app_focus_service.html#ga28a3e31c137ca5d5c563701aee986726", null ],
    [ "AppFocusHandler", "group___app_focus_service.html#ga187618cef767c489b8cc95cc3b2192e1", null ]
];