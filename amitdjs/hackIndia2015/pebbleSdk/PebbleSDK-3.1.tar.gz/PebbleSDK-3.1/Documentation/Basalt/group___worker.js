var group___worker =
[
    [ "worker_event_loop", "group___worker.html#gaba624492af6173015c4923120fa47e35", null ],
    [ "worker_launch_app", "group___worker.html#ga4ac41d61177b9b631a1a09f04eaf4b2c", null ]
];