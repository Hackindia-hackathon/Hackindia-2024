var group___app_sync =
[
    [ "app_sync_deinit", "group___app_sync.html#ga87669e4513866da4328edd460a9417e7", null ],
    [ "app_sync_get", "group___app_sync.html#gafd27a0705ca3cb01f731f418b790c445", null ],
    [ "app_sync_init", "group___app_sync.html#ga329a8fa4a27bb8b15cee9ffcc4a026df", null ],
    [ "app_sync_set", "group___app_sync.html#gaa5f51f1d7914b3617fdee104d1488108", null ],
    [ "AppSyncErrorCallback", "group___app_sync.html#ga144a1a8d8050f8f279b11cfb5d526212", null ],
    [ "AppSyncTupleChangedCallback", "group___app_sync.html#ga448af36883189f6345cc7d5cd8a3cc29", null ]
];