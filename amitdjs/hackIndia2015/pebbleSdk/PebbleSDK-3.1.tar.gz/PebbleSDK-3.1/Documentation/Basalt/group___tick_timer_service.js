var group___tick_timer_service =
[
    [ "tick_timer_service_subscribe", "group___tick_timer_service.html#ga8b1ebbe9ca26a97b23af5610842bc892", null ],
    [ "tick_timer_service_unsubscribe", "group___tick_timer_service.html#gaae157828fd8c8d1e8de6372d0a3aa25e", null ],
    [ "TickHandler", "group___tick_timer_service.html#gaa3777b83676624511fa63eea7fed2eaa", null ],
    [ "TimeUnits", "group___tick_timer_service.html#ga0423d00e0eb199de523a92031b5a1107", [
      [ "SECOND_UNIT", "group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107afd448b8fbcd39321d18aa41b62b308b9", null ],
      [ "MINUTE_UNIT", "group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107af135dc6b67dce70c7b4b961605aa6970", null ],
      [ "HOUR_UNIT", "group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107a7628af862ee9aa0b56cdfc1cea7e0f79", null ],
      [ "DAY_UNIT", "group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107af990f18a7186e6b386f36f2afa3c8038", null ],
      [ "MONTH_UNIT", "group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107ac5c028cac926fb83169e7b43fa089b16", null ],
      [ "YEAR_UNIT", "group___tick_timer_service.html#gga0423d00e0eb199de523a92031b5a1107a652f00ea2c629930a32a684f9d8c876d", null ]
    ] ]
];