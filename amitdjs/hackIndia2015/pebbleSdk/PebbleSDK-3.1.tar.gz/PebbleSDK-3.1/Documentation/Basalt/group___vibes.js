var group___vibes =
[
    [ "vibes_cancel", "group___vibes.html#gad190fd7825ec34d96d0ef05508275169", null ],
    [ "vibes_double_pulse", "group___vibes.html#gab248dc8961ee1356a106599e3aeef00a", null ],
    [ "vibes_enqueue_custom_pattern", "group___vibes.html#ga3412ed26dd91a20f77ba1a4c54b668e1", null ],
    [ "vibes_long_pulse", "group___vibes.html#ga93e5ca695c1ff3ed096b7f1b5cb29d44", null ],
    [ "vibes_short_pulse", "group___vibes.html#gaa5acf97e140e066834c1963da7f1d5db", null ]
];